<?php

class Afinidade extends Eloquent {
	protected $table = 'afinidades';
	public $timestamps = false;
}