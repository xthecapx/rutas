<?php

class TitulacionController extends BaseController {

	public function getIndex()
	{
		return View::make('dobleTitulacion.index');
	}
}