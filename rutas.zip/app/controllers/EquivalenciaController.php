<?php

class EquivalenciaController extends BaseController {

	public function getIndex()
	{
		return View::make('dobleTitulacion.equivalencias');
	}

	public function postIndex()
	{
		$FORMactual = $_POST["programa_actual"];
		$FORMopcion = $_POST["programa_destino"];

		$equivalencia = Equivalencia::where('idProgramaActual', '=', $FORMactual)
							->where('idProgramaDestino', '=', $FORMopcion)
							->first();
		if($equivalencia == null){
			return Redirect::to('/titulacion/equivalencias')->with('message','La carrerea seleccionada no registra equivalencias');
		}
		$aequivalencias = Equivalencia::find($equivalencia->id)->Aequivalencias;

		//return $equivalencia . '<br>' . '<br>' . $equivalencias;
		return View::make('dobleTitulacion.showe')->with('equivalencia',$equivalencia)
												  ->with('aequivalencias', $aequivalencias);
	}
}