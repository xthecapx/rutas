@extends('layouts.master')

@section('breadcrumb')
	<a href="/">Inicio</a> / <a href="/programa">Rutas</a> / <a href="/programa/perfil/{{$perfil}}">Perfiles</a> / Estas viendo: <strong>Asignaturas</strong>
@stop

@section('content')
	<div class="idcard">
		<div class="idcard_content">
			<div class="idcard_head">
				<strong>Perfil: </strong>{{ucwords($perfil_nombre)}}
			</div>

			<div class="perfiles">
				<p class="pcenter">Las asignatura asociadas al perfil {{ucwords($perfil_nombre)}} son: </p>
				@if(count($datos) == 0)
					{{'El perfil ' . ucwords($perfil_nombre) . ' no tiene asignaturas asociadas'}}
				@else
					@foreach($datos as $item)
						<a>
							<div class="item perfiles_asignatura" id="asignatura">
								<div class="tituloasignatura">{{$item["asignatura"]}}</div>
								<p>
									<span>Codigo: </span>{{$item["asignatura_id"]}} <br>
									<span>Créditos: </span>{{$item["creditos"]}} <br>
									<span>Tipologia: </span>{{$item["tipologia"]}}
								</p>
								<span class="r-arrow-down icono2" id="bajar"></span>
								<div class="Requisitos">
									<div class="tituloasignatura">Requisitos</div>
									<ol>
										@foreach($item["requisitos"] as $item)
											<li>{{$item["requisito"]}}</li>
										@endforeach
									</ol>
								</div>
							</div>
						</a>	
					@endforeach
				@endif
			</div>
		</div>
	</div>

<script>
	$("div.Requisitos").hide();
	$("div#asignatura").click(function(){
		$(this).children("div.Requisitos").slideToggle("slow");
		$(this).children("span#bajar").toggleClass("r-arrow-up" ,"r-arrow-down");
	});
</script>
@stop

@section('right')
	<nav class="menuright">
        <ul class="awesome-ul">
        	<li>
        		<a href="/">Inicio</a>
        	</li>
        	<li class="active">
        		<a href="/programa">Rutas</a>
        	</li>
        	<li>
        		<a href="/titulacion">Doble Titulación</a>
        		<ul>
        		    <li><a href="/titulacion/afinidad">Afinidades</a></li>
        		    <li><a href="/titulacion/equivalencias">Equivalencias</a></li>
        		</ul>
        	</li>
        	<li>
        		<a href="/contacto">Contacto</a>
        	</li>
        </ul>
    </nav>

    <nav class="menuright anterior">
        <ul class="awesome-ul">
        	<li class="active">
        		<a href="/programa/perfil/{{$perfil}}"> <span class="r-undo"></span> <span class="textAnterior">Anterior</span> </a>
        	</li>
        </ul>
    </nav>
@stop