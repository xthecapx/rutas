@extends('layouts.master')

@section('breadcrumb')
	<a href="/">Inicio</a> / Estas viendo: <strong>Asignaturas</strong>
@stop

@section('content')
	<div class="idcard">
		<div class="idcard_content">
			<div class="idcard_head">
				<strong>Perfil: </strong>{{ucwords($perfil->perfil)}}
			</div>

			<div class="perfiles">
				<p class="pcenter">Las asignatura asociadas al perfil {{ucwords($perfil->perfil)}} son: </p>
				@if(count($perfil->asignaturas()->get()) == 0)
					{{'El perfil ' . ucwords($perfil->perfil) . ' no tiene asignaturas asociadas'}}
				@else
					@foreach($perfil->asignaturas()->get() as $item)
						<a href="/programa/requisito/{{$perfil->id}}/{{$item->id}}">
							<div class="item perfiles_asignatura" id="asignaturas">
								<p class="left"><span>Codigo: </span>{{$item->id}} <br>
								<span>Créditos: </span>{{$item->creditos}}</p>
								<p><span>Nombre: </span>{{$item->asignatura}}</p>
								<span class="icon-zoomin2 icono"></span>
							</div>
						</a>	
					@endforeach
				@endif
			</div>
		</div>
	</div>
@stop


@section('right')
	<nav class="menuright">
        <ul class="awesome-ul">
        	<li>
        		<a href="/">Inicio</a>
        	</li>
        	<li class="active">
        		<a href="/programa">Rutas</a>
        	</li>
        	<li>
        		<a href="/titulacion">Doble Titulación</a>
        		<ul>
        		    <li><a href="/titulacion/afinidad">Afinidades</a></li>
        		    <li><a href="/titulacion/equivalencias">Equivalencias</a></li>
        		</ul>
        	</li>
        	<li>
        		<a href="/contacto">Contacto</a>
        	</li>
        </ul>
    </nav>

    <nav class="menuright">
        <ul class="awesome-ul">
        	<li class="active">
        		<a href="/programa/perfil/{{$perfil->id}}"> <span class="r-undo"></span> Anterior</a>
        	</li>
        </ul>
    </nav>
@stop