@extends('layouts.master')

@section('breadcrumb')
	<a href="/">Inicio</a> / <a href="/programa">Rutas</a> / Estas viendo: <strong>Perfiles</strong>
@stop

@section('content')
	<div class="idcard">
		<div class="idcard_content">
			<div class="idcard_head">
				<strong>{{ucwords($programa->sede)}}</strong> | {{ ucwords($programa->facultad)}} | {{ucwords($programa->programa)}}
			</div>

			<div class="perfiles">
				<p class="pcenter">Selecciona el perfil de tu interés:</p>
				@foreach($perfil as $item)
					<a href="/programa/asignatura/{{$item->id}}">
						<div class="item items_perfiles">
                            <span class="r-flow-tree left"></span>
                            <span class="r-zoomin2 icono"></span>
                            <div class="perfiles_contenedor">
    							<h5><span>Nombre: </span>{{$item->perfil}} | {{$item->total_creditos}} Créditos</h5>
    							<p class="justificado"><span>Descripción: </span>{{$item->descripcion}}</p>
                            </div>
						</div>
					</a>
				@endforeach
			</div>
		</div>
	</div>
@stop

@section('right')
	<nav class="menuright">
        <ul class="awesome-ul">
        	<li>
        		<a href="/">Inicio</a>
        	</li>
        	<li class="active">
        		<a href="/programa">Rutas</a>
        	</li>
        	<li>
        		<a href="/titulacion">Doble Titulación</a>
        		<ul>
        		    <li><a href="/titulacion/afinidad">Afinidades</a></li>
        		    <li><a href="/titulacion/equivalencias">Equivalencias</a></li>
        		</ul>
        	</li>
        	<li>
        		<a href="/contacto">Contacto</a>
        	</li>
        </ul>
    </nav>
	<nav class="menuright anterior">
        <ul class="awesome-ul">
        	<li class="active">
        		<a href="{{URL::previous()}}"> <span class="r-undo"></span> <span class="textAnterior">Anterior</span> </a>
        	</li>
        </ul>
    </nav>
@stop