@extends('layouts.master')

@section('breadcrumb')
	<h4>Bienvenido al sistema de Rutas Curriculares</h4>
@stop


@section('content')
    {{ Form::open(array('class' => 'unal-form'))}}

        <select name="sede" id="sede"></select><br>
        <select name="facultad" id="facultad"></select><br>
    	<select name="programa" id="programa"></select><br>

    	{{Form::submit('Continuar', array('id' => 'submitbutton'));}}
    {{ Form::close()}}

    <p>{{Session::get('message');}}</p>

    <script>
    $(document).ready(function(){

        $("#submitbutton").attr("disabled", true);

        $("#programa").focus(function(){$("#submitbutton").attr("disabled", false);});

        $("#sede").jCombo({
            url: "{{url('sedes')}}",
            initial_text: "1. Seleccione la sede.",
        });
        
        $("#facultad").jCombo({
            url: "{{url('facultades')}}", 
            input_param: "option",
            initial_text: "2. Seleccione la facultad.",
            parent: "#sede",
        });

        $("#programa").jCombo({
            url: "{{url('programas')}}", 
            input_param: "option",
            initial_text: "3. Seleccione el programa.",
            parent: "#facultad",
        });
    });   
    </script>
@stop

@section('right')
    <nav class="menuright">
        {{ $MenuPrincipal->asUl( array('class' => 'awesome-ul') ) }}
    </nav>
@stop