<p> Nuevo mensaje: </p>

<p>Información</p>

<p>Nombre: {{$nombre}} </p>
<p>Email: {{$email}} </p>
<p>Comentario: {{$comentario}} </p>
 