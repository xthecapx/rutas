@extends('layouts.master')

@section('breadcrumb')
	<h4>Bienvenido al sistema de Rutas Curriculares</h4>
@stop


@section('content')
    {{ Form::open(array( 'url' => 'titulacion/afinidad' ,'class' => 'unal-form'))}}

        <select name="sedeOrigen" id="sedeOrigen"></select><br>
        <select name="programaOrigen" id="programaOrigen"></select><br>

    	{{Form::submit('Continuar', array('id' => 'submitbutton'));}}
    {{ Form::close()}}

    <p>{{Session::get('message');}}</p>

    <script>
    $(document).ready(function(){

        $("#submitbutton").attr("disabled", true);

        $("#programaOrigen").focus(function(){$("#submitbutton").attr("disabled", false);});

        $("#sedeOrigen").jCombo({
            url: "{{url('sedeOrigen')}}",
            initial_text: "1. Seleccione la Sede origen.",
        });

        $("#programaOrigen").jCombo({
            url: "{{url('programaOrigen')}}",
            input_param: "option",
            initial_text: "2. Seleccione el programa origen.",
            parent: "#sedeOrigen",
        });

    });   
    </script>
@stop

@section('right')
    <nav class="menuright">
        {{ $MenuPrincipal->asUl( array('class' => 'awesome-ul') ) }}
    </nav>
@stop