@extends('layouts.master')

@section('breadcrumb')
	<h4>Bienvenido al sistema de Rutas Curriculares</h4>
@stop

@section('content')
<center>
	<h1>
		<span class="r-tongue"></span> <span class="r-sad"></span> <span class="r-wink"></span> <span class="r-wink2"></span> <span class="r-grin"></span>

		<br><br>

		Lo sentimos esta aplicación no funciona en Internet Explorer <span class="r-IE"></span>, te recomendamos utilizar un mejor Browser <a href="http://www.google.com/intl/es-419/chrome/"><span class="r-chrome"></span></a> <a href="https://www.mozilla.org/es-ES/firefox/new/"><span class="r-firefox"></span></a> <a href="http://www.opera.com/es-419"><span class="r-opera"></span></a> <a href="https://www.apple.com/es/safari/"> <span class="r-safari"></span></a>. 
		
	</h1>
</center>
@stop