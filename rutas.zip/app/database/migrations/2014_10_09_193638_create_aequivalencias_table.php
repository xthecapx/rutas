<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateAequivalenciasTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('aequivalencias', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('equivalencia_id')->unsigned()->index();
			$table->foreign('equivalencia_id')->references('id')->on('equivalencias');
			$table->string('asignatura_inicial');
			$table->string('asignatura_equivalente');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('aequivalencias');
	}

}
