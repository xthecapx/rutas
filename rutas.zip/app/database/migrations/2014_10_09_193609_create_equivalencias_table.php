<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateEquivalenciasTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('equivalencias', function(Blueprint $table)
		{
			$table->increments('id');
			/*$table->integer('programa_actual')->unsigned()->index();
			$table->foreign('programa_actual')->references('id')->on('programas');
			$table->integer('programa_destino')->unsigned()->index();
			$table->foreign('programa_destino')->references('id')->on('programas');*/
			$table->integer('idProgramaActual');
			$table->string('programa_actual');
			$table->integer('idProgramaDestino');
			$table->string('programa_destino');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('equivalencias');
	}

}
